package com.example.online_shopping

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
